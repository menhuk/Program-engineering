﻿using AntiBook.Data;
using AntiBook.Dtos.Books;
using AntiBook.Mappers;
using AntiBook.Models;
using Microsoft.AspNetCore.Mvc;
using static AntiBook.Data.ApplicationDBContext;
namespace AntiBook.Controllers
{
    [Route("AntiBook/Books")]
    [ApiController]
    public class BooksControllers : ControllerBase
    {
        private readonly AppliacationDBContex _context;
        public BooksControllers(AppliacationDBContex contex)
        {
            _context = contex;
        }
        [HttpGet]
        public ActionResult GetAll()
        {
            var books = _context.Books.ToList().Select(s => s.ToBooksDto());
            return Ok(books);
        }
        [HttpGet("{id}")]
        public IActionResult GetById([FromRoute] int id)
        {
            var books = _context.Books.Find(id);
            if (books == null)
            {
                return NotFound();

            }
            return Ok(books.ToBooksDto());
        }
        [HttpPost]
        public IActionResult Create([FromBody] CreateBooksRequestDto bookDto)
        {
            var bookModel = bookDto.ToBooksFromCreateDto();
            _context.Books.Add(bookModel);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetById), new {id =  bookModel.Id},bookModel.ToBooksDto());
        }
        [HttpPut]
        [Route("{id}")]
        public IActionResult Update([FromRoute] int id, [FromBody] UpdateBooksRequestDto updateDto)
        {
            var bookModel = _context.Books.FirstOrDefault(x => x.Id == id);
            if (bookModel == null)
            {
                return NotFound();
            }
            bookModel.Title = updateDto.Title;
            bookModel.Author_id = updateDto.Author_id;
            bookModel.Year = updateDto.Year;
            bookModel.Current_owner_id = updateDto.Current_owner_id;
            bookModel.Genre_id = updateDto.Genre_id;
            bookModel.Secondary_genre_id = updateDto.Secondary_genre_id;
            bookModel.Tertiary_genre_id = updateDto.Tertiary_genre_id;
            bookModel.Pages = updateDto.Pages;
            bookModel.Bookhouse_id = updateDto.Bookhouse_id;
            bookModel.Coverage_id = updateDto.Coverage_id;
            bookModel.Language_id = updateDto.Language_id;
            bookModel.Translation = updateDto.Translation;
            bookModel.Translator_id = updateDto.Translator_id;
            _context.SaveChanges();
            return Ok(bookModel.ToBooksDto());
        }
        [HttpDelete]
        [Route("{id}")]
        public IActionResult Delete([FromRoute] int id)
        {
            var bookModel = _context.Books.FirstOrDefault(x => x.Id == id);
            if (bookModel == null)
            {
                return NotFound();
            }
            _context.Books.Remove(bookModel);
            _context.SaveChanges();
            return NoContent();
        }
    }
}
