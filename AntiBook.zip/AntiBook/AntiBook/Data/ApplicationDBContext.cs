﻿using AntiBook.Models;
using Microsoft.EntityFrameworkCore;

namespace AntiBook.Data
{
    public class ApplicationDBContext: DbContext
    {
        public class AppliacationDBContex : DbContext
        {
            public AppliacationDBContex(DbContextOptions dbContextOptions) :
                base(dbContextOptions)
            {

            }
            public DbSet<Books> Books { get; set; }
            public DbSet<Authors> Authors { get; set; }
            public DbSet<Bookhouse> Bookhouses { get; set; }
            public DbSet<Cities> Cities { get; set; }
            public DbSet<Coverages> Coverages { get; set; }
            public DbSet<Genres> Genres { get; set; }
            public DbSet<Languages> Languages { get; set; }
            public DbSet<Rent_log> Rent_Logs { get; set; }
            public DbSet<Users> Users { get; set; }
        }
    }
}
