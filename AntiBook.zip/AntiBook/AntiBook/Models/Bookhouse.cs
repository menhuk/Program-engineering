﻿namespace AntiBook.Models
{
    public class Bookhouse
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int city_id { get; set; }
        
    }
}
