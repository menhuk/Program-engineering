﻿namespace AntiBook.Models
{
    public class Cities
    {
        public int Id { get; set; }
        public string city_name { get; set; } = string.Empty;
        public int city_code { get; set; }

    }
}
