﻿namespace AntiBook.Models
{
    public class Coverages
    {
        public int Id { get; set; }
        public string coverage_name { get; set; } = string.Empty;
    }
}
