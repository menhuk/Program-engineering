﻿namespace AntiBook.Models
{
    public class Genres
    {
        public int Id { get; set; }
        public string genre_name { get; set; } = string.Empty;
    }
}
