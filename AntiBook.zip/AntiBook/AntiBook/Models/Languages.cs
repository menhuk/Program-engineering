﻿namespace AntiBook.Models
{
    public class Languages
    {
        public int Id { get; set; }
        public string genre_name { get; set; } = string.Empty;
        public string language_code { get; set; } = string.Empty;
    }
}
